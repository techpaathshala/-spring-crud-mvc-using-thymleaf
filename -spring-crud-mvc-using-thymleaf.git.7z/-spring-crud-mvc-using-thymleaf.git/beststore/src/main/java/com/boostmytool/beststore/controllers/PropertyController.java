package com.boostmytool.beststore.controllers;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PropertyController {

    @Value("${product.defaultName}")
    private String defaultProductName;

    @Value("${product.defaultBrand}")
    private String defaultProductBrand;

    @Value("${product.defaultCategory}")
    private String defaultProductCategory;

    @Value("${product.defaultPrice}")
    private double defaultProductPrice;

    @Value("${product.defaultDescription}")
    private String defaultProductDescription;

    @GetMapping("/properties")
    public String getProperties() {
        return "Default Product Name: " + defaultProductName + "<br>"
                + "Default Product Brand: " + defaultProductBrand + "<br>"
                + "Default Product Category: " + defaultProductCategory + "<br>"
                + "Default Product Price: " + defaultProductPrice + "<br>"
                + "Default Product Description: " + defaultProductDescription;
    }
}
